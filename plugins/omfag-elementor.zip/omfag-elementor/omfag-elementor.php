<?php
/**
 * Plugin Name: OMFag Elementor Addon
 * Description: Custom Elementor addon For OMFag Theme.
 * Plugin URI:  https://github.com/ashrafulsarkar
 * Version:     1.0.0
 * Author:      Ashraful Sarkar Naiem
 * Author URI:  https://github.com/ashrafulsarkar
 * Text Domain: smfelementor
 * 
 * Elementor tested up to: 3.7.0
 * Elementor Pro tested up to: 3.7.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
define( 'OMFAG_ELEMENTOR_URL', plugin_dir_url(__FILE__) );
define( 'OMFAG_ELEMENTOR_CSS', OMFAG_ELEMENTOR_URL .'assets/css' );
define( 'OMFAG_ELEMENTOR_JS', OMFAG_ELEMENTOR_URL .'assets/js' );

function omfag_elementor_addon() {

	// Load plugin file
	require_once( __DIR__ . '/includes/plugin.php' );

	// Run the plugin
	\OMFag_Elementor_Addon\Plugin::instance();

}
add_action( 'plugins_loaded', 'omfag_elementor_addon' );