<?php
namespace OMFag_Elementor_Addon;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class OMFag_About_Slider extends \Elementor\Widget_Base {

	public function get_name() {
		return 'omfag_about_slider';
	}

	public function get_title() {
		return esc_html__( 'OMFag About Slider', 'omfag' );
	}

	public function get_icon() {
		return 'eicon-slider-vertical';
	}

	public function get_custom_help_url() {
		return 'https://developers.elementor.com/docs/widgets/';
	}

	public function get_categories() {
		return [ 'omfag' ];
	}

	public function get_keywords() {
		return [ 'slider' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Slider Options', 'omfag' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'omfag' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Über uns', 'omfag' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'content',
			[
				'label' => esc_html__( 'Content', 'omfag' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => esc_html__( 'Unser Team aus erfahrenen Fachleuten legt großen Wert auf herausragende Qualität, Zuverlässigkeit und Kundenzufriedenheit.' , 'omfag' ),
				'show_label' => false,
			]
		);

		$repeater->add_control(
			'image',
			[
				'label'   => esc_html__( 'Image', 'omfag' ),
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'btn_text',
			[
				'label' => esc_html__( 'Button Text', 'omfag' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Mehr erfahren', 'omfag' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'btn_link',
			[
				'label' => esc_html__( 'Button Link', 'omfag' ),
				'type' => \Elementor\Controls_Manager::URL,
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '#',
				],
				'label_block' => true,
			]
		);

		$this->add_control(
			'slider',
			[
				'label' => esc_html__( 'Slider List', 'omfag' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'list_title' => esc_html__( 'Title #1', 'omfag' ),
					],
				],
			]
		);

		$this->add_control(
			'slider_spreed',
			[
				'label'       => esc_html__( 'Slider Spreed', 'omfag' ),
				'type'        => \Elementor\Controls_Manager::NUMBER,
				'default'     => 7000,
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Content Style', 'omfag' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Title Color', 'omfag' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#000B07',
				'selectors' => [
					'{{WRAPPER}} .slider_content h3' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .slider_content h3',
			]
		);


		$this->add_control(
			'content_color',
			[
				'label'     => esc_html__( 'Content Color', 'omfag' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#000B07',
				'selectors' => [
					'{{WRAPPER}} .slider_content p' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'content_typography',
				'selector' => '{{WRAPPER}} .slider_content p',
			]
		);
		
		$this->add_responsive_control(
			'content_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'omfag' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'default'    => [
					'unit'   => 'px',
					'top'    => '0',
					'right'  => '0',
					'bottom' => '8',
					'left'   => '0',
				],
				'selectors'  => [
					'{{WRAPPER}} .slider_content h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'content_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'omfag' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'default'    => [
					'unit'   => 'px',
					'top'    => '10',
					'right'  => '10',
					'bottom' => '10',
					'left'   => '10',
				],
				'selectors'  => [
					'{{WRAPPER}} .slider_details, {{WRAPPER}} .about_slider_item img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'btn_style',
			[
				'label' => esc_html__( 'Button Style', 'omfag' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'btn_color',
			[
				'label'     => esc_html__( 'Color', 'omfag' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#4BBAB1',
				'selectors' => [
					'{{WRAPPER}} .slider_btn a' => 'color: {{VALUE}}; border-color:{{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'btn_typography',
				'selector' => '{{WRAPPER}} .slider_btn a',
			]
		);
		
		$this->add_responsive_control(
			'btn_padding',
			[
				'label'      => esc_html__( 'Padding', 'omfag' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'default'    => [
					'unit'   => 'px',
					'top'    => '20',
					'right'  => '60',
					'bottom' => '20',
					'left'   => '60',
				],
				'selectors'  => [
					'{{WRAPPER}} .slider_btn a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'btn_border_width',
			[
				'label'      => esc_html__( 'Border Width', 'omfag' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'default'    => [
					'unit'   => 'px',
					'top'    => '2',
					'right'  => '2',
					'bottom' => '2',
					'left'   => '2',
				],
				'selectors'  => [
					'{{WRAPPER}} .slider_btn a' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'btn_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'omfag' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'default'    => [
					'unit'   => 'px',
					'top'    => '10',
					'right'  => '10',
					'bottom' => '10',
					'left'   => '10',
				],
				'selectors'  => [
					'{{WRAPPER}} .slider_btn a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->end_controls_section();
	}

	/**
	 * Render list widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$items_id = $this->get_id();
		?>
		<div class="row">
			<div class="col-12">
				<div class="omfag_about_slider about_slider_<?php echo $items_id;?>">
					<ul class="silder_dots">
					<?php if ( $settings['slider'] ) {
						foreach (  $settings['slider'] as $item ) { ?>
						<li class="dot <?php echo $settings['slider'][0] == $item ? 'dot-active':'' ;?>"><span></span></li>
					<?php } } ?>
					</ul>

					<?php
					if ( $settings['slider'] ) {
						foreach (  $settings['slider'] as $item ) { ?>
						<div class="about_slider_item <?php echo $settings['slider'][0] == $item ? 'omgaf_slider_active':'' ;?>" >
							<div class="row align-items-stretch">
								<div class="col-lg-5">
									<div class="slider_details">
										<div class="slider_content">
											<h3><?php echo $item['title'];?></h3>
											<p><?php echo $item['content'];?></p>
										</div>
										<div class="slider_btn">
											<a href="<?php echo $item['btn_link']['url'];?>"><?php echo $item['btn_text'];?> <i class="fa-solid fa-arrow-right-long"></i></a>
										</div>
									</div>
								</div>
								<div class="col-lg-7">
									<img src="<?php echo $item['image']['url'];?>">
								</div>
							</div>
						</div>
					<?php } } ?>
					<script>
					const divs = document.querySelectorAll('.about_slider_<?php echo $items_id;?> .about_slider_item');
					const dots = document.querySelectorAll('.about_slider_<?php echo $items_id;?> li.dot');

					let currentIndex = 0;

					function showNextDiv() {
					 	// divs[currentIndex].style.display = 'none';
					 	divs[currentIndex].classList.remove('omgaf_slider_active');
					 	dots[currentIndex].classList.remove('dot-active');

					 	currentIndex = (currentIndex + 1) % divs.length;
					 	// divs[currentIndex].style.display = 'block';
						divs[currentIndex].classList.add('omgaf_slider_active');
						dots[currentIndex].classList.add('dot-active');
					}

					dots.forEach((dot) => {
						dot.style.height = 100 /  divs.length+'%';
					});

					function handleResize() {
						const slider_details = document.querySelectorAll('.slider_details');
						const silder_dots = document.querySelectorAll('.silder_dots');

						let totalHeight = 0;

						slider_details.forEach((div) => {
							totalHeight += div.clientHeight;
						});
						
						silder_dots.forEach((dot) => {
							dot.style.height = (totalHeight - 64)+'px';
						});
					}

					window.addEventListener('resize', handleResize);
					window.onload = handleResize();
					
					setInterval(showNextDiv, <?php echo $settings['slider_spreed']; ?>);

					</script>
				</div>
			</div>
		</div>
        
		<?php
	}

	/**
	 * Render list widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() {}
}