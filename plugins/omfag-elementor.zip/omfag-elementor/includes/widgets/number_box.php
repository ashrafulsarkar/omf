<?php
namespace OMFag_Elementor_Addon;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class OMFag_Number_Box extends \Elementor\Widget_Base {

	public function get_name() {
		return 'omfag_number_box';
	}

	public function get_title() {
		return esc_html__( 'OMFag Number Box', 'omfag' );
	}

	public function get_icon() {
		return 'eicon-number-field';
	}

	public function get_custom_help_url() {
		return 'https://developers.elementor.com/docs/widgets/';
	}

	public function get_categories() {
		return [ 'omfag' ];
	}

	public function get_keywords() {
		return [ 'number', 'box', 'card' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Number Box', 'omfag' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'number_title',
			[
				'label'       => esc_html__( 'Number', 'omfag' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( '01', 'omfag' ),
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'omfag' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Kontaktaufnahme', 'omfag' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'content',
			[
				'label'       => esc_html__( 'Content', 'omfag' ),
				'type'        => \Elementor\Controls_Manager::WYSIWYG,
				'default'     => esc_html__( 'Nehmen Sie Kontakt mit uns auf, um Ihr Interesse zu bekunden oder Fragen zu stellen. Unser freundliches Team ist bereit, Ihre Anfragen zu beantworten.', 'omfag' ),
				'label_block' => true,
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
			'box_style',
			[
				'label' => esc_html__( 'Box Style', 'omfag' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'box_padding',
			[
				'label'      => esc_html__( 'Padding', 'omfag' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'default'    => [
					'unit'   => 'px',
					'top'    => '32',
					'right'  => '32',
					'bottom' => '32',
					'left'   => '32',
				],
				'selectors'  => [
					'{{WRAPPER}} .omfag_number_box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'box_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'omfag' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'default'    => [
					'unit'   => 'px',
					'top'    => '10',
					'right'  => '10',
					'bottom' => '10',
					'left'   => '10',
				],
				'selectors'  => [
					'{{WRAPPER}} .omfag_number_box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'box_border_width',
			[
				'label'      => esc_html__( 'Border Width', 'omfag' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'default'    => [
					'unit'   => 'px',
					'top'    => '1',
					'right'  => '1',
					'bottom' => '1',
					'left'   => '1',
				],
				'selectors'  => [
					'{{WRAPPER}} .omfag_number_box' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'box_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'omfag' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#4BBAB1',
				'selectors' => [
					'{{WRAPPER}} .omfag_number_box' => 'border-color:{{VALUE}}',
				],
			]
		);

		$this->add_control(
			'box_bg_color',
			[
				'label'     => esc_html__( 'Background', 'omfag' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#fff',
				'selectors' => [
					'{{WRAPPER}} .omfag_number_box' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'box_hover_bg_color',
			[
				'label'     => esc_html__( 'Background Hover Color', 'omfag' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#4BBAB1',
				'selectors' => [
					'{{WRAPPER}} .omfag_number_box:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'height',
			[
				'label' => esc_html__( 'Height', 'omfag' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range' => [
					'px' => [
						'min' => 150,
						'max' => 500,
						'step' => 1,
					]
				],
				'default' => [
					'unit' => 'px',
					'size' => 280,
				],
				'selectors' => [
					'{{WRAPPER}} .omfag_number_box' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'number_style',
			[
				'label' => esc_html__( 'Number Style', 'omfag' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'number_align',
			[
				'label' => esc_html__( 'Alignment', 'omfag' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'omfag' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'omfag' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'omfag' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .omfag_number_box h4' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'number_color',
			[
				'label'     => esc_html__( 'Color', 'omfag' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#000B07',
				'selectors' => [
					'{{WRAPPER}} .omfag_number_box h4' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'number_hover_color',
			[
				'label'     => esc_html__( 'Hover Color', 'omfag' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#fff',
				'selectors' => [
					'{{WRAPPER}} .omfag_number_box:hover h4' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'number_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'omfag' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#F1F3F2',
				'selectors' => [
					'{{WRAPPER}} .omfag_number_box h4' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'number_typography',
				'selector' => '{{WRAPPER}} .omfag_number_box h4',
			]
		);

		$this->add_responsive_control(
			'number_padding',
			[
				'label'      => esc_html__( 'Padding', 'omfag' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'default'    => [
					'unit'   => 'px',
					'top'    => '8',
					'right'  => '20',
					'bottom' => '8',
					'left'   => '20',
				],
				'selectors'  => [
					'{{WRAPPER}} .omfag_number_box h4' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'number_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'omfag' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'default'    => [
					'unit'   => 'px',
					'top'    => '10',
					'right'  => '10',
					'bottom' => '10',
					'left'   => '10',
				],
				'selectors'  => [
					'{{WRAPPER}} .omfag_number_box h4, {{WRAPPER}} .omfag_image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title Style', 'omfag' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'text_align',
			[
				'label' => esc_html__( 'Alignment', 'omfag' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'omfag' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'omfag' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'omfag' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .omfag_number_box h2' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'omfag' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#000B07',
				'selectors' => [
					'{{WRAPPER}} .omfag_number_box h2' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_hover_color',
			[
				'label'     => esc_html__( 'Hover Color', 'omfag' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#fff',
				'selectors' => [
					'{{WRAPPER}} .omfag_number_box:hover h2' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .omfag_number_box h2',
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'content_style',
			[
				'label' => esc_html__( 'Content Style', 'omfag' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'content_align',
			[
				'label' => esc_html__( 'Alignment', 'omfag' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'omfag' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'omfag' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'omfag' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .omfag_number_box p' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'content_color',
			[
				'label'     => esc_html__( 'Color', 'omfag' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#000B07',
				'selectors' => [
					'{{WRAPPER}} .omfag_number_box p' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'content_hover_color',
			[
				'label'     => esc_html__( 'Hover Color', 'omfag' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#fff',
				'selectors' => [
					'{{WRAPPER}} .omfag_number_box:hover p' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'content_typography',
				'selector' => '{{WRAPPER}} .omfag_number_box p',
			]
		);
		
		$this->end_controls_section();
	}

	/**
	 * Render list widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
        <div class="omfag_number_box">
			<h4><?php echo $settings['number_title'];?></h4>
			<h2><?php echo $settings['title'];?></h2>
            <p><?php echo $settings['content'];?></p>
        </div>
		<?php
	}

	/**
	 * Render list widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() {}
}