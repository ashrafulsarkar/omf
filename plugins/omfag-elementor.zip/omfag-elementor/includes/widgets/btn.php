<?php
namespace OMFag_Elementor_Addon;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class OMFag_Btn extends \Elementor\Widget_Base {

	public function get_name() {
		return 'omfag_btn';
	}

	public function get_title() {
		return esc_html__( 'OMFag Button', 'omfag' );
	}

	public function get_icon() {
		return 'eicon-button';
	}

	public function get_custom_help_url() {
		return 'https://developers.elementor.com/docs/widgets/';
	}

	public function get_categories() {
		return [ 'omfag' ];
	}

	public function get_keywords() {
		return [ 'btn', 'button' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'omfag' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Button Text', 'omfag' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Energieeinsparung', 'omfag' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'btn_url',
			[
				'label'       => esc_html__( 'Button URL', 'omfag' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '#',
				],
				'label_block' => true,
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
			'button_style',
			[
				'label' => esc_html__( 'Button Style', 'omfag' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'btn_bg_color',
			[
				'label'     => esc_html__( 'Background', 'omfag' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#fff',
				'selectors' => [
					'{{WRAPPER}} .omfag_btn' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'btn_bg_hover_color',
			[
				'label'     => esc_html__( 'Background Hover', 'omfag' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#4BBAB1',
				'selectors' => [
					'{{WRAPPER}} .omfag_btn:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'box_padding',
			[
				'label'      => esc_html__( 'Padding', 'omfag' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'default'    => [
					'unit'   => 'px',
					'top'    => '24',
					'right'  => '40',
					'bottom' => '24',
					'left'   => '40',
				],
				'selectors'  => [
					'{{WRAPPER}} .omfag_btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'btn_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'omfag' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'default'    => [
					'unit'   => 'px',
					'top'    => '10',
					'right'  => '10',
					'bottom' => '10',
					'left'   => '10',
				],
				'selectors'  => [
					'{{WRAPPER}} .omfag_btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'btn_border_width',
			[
				'label'      => esc_html__( 'Border Width', 'omfag' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'default'    => [
					'unit'   => 'px',
					'top'    => '1',
					'right'  => '1',
					'bottom' => '1',
					'left'   => '1',
				],
				'selectors'  => [
					'{{WRAPPER}} .omfag_btn' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'btn_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'omfag' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#4BBAB1',
				'selectors' => [
					'{{WRAPPER}} .omfag_btn' => 'border-color: {{VALUE}};',
				],
			]
		);
		

		$this->add_control(
			'btn_hr',
			[
				'type'      => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Title Color', 'omfag' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#4BBAB1',
				'selectors' => [
					'{{WRAPPER}} .omfag_btn span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_hover_color',
			[
				'label'     => esc_html__( 'Hover Color', 'omfag' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#fff',
				'selectors' => [
					'{{WRAPPER}} .omfag_btn:hover span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .omfag_btn span',
			]
		);

		$this->add_control(
			'icon_hr',
			[
				'type'      => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label'     => esc_html__( 'Icon Color', 'omfag' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#fff',
				'selectors' => [
					'{{WRAPPER}} .omfag_btn .icon i' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'icon_typography',
				'selector' => '{{WRAPPER}} .omfag_btn .icon i',
			]
		);

		$this->add_control(
			'icon_bg_color',
			[
				'label'     => esc_html__( 'Background', 'omfag' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#4BBAB1',
				'selectors' => [
					'{{WRAPPER}} .omfag_btn .icon' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_bg_hover_color',
			[
				'label'     => esc_html__( 'Background Hover', 'omfag' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => 'rgba(255, 255, 255, 0.30)',
				'selectors' => [
					'{{WRAPPER}} .omfag_btn:hover .icon' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'width',
			[
				'label' => esc_html__( 'Icon Width', 'omfag' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 20,
						'max' => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 70,
				],
				'selectors' => [
					'{{WRAPPER}} .omfag_btn .icon' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'height',
			[
				'label' => esc_html__( 'Icon Height', 'omfag' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 20,
						'max' => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 58,
				],
				'selectors' => [
					'{{WRAPPER}} .omfag_btn .icon' => 'height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'omfag' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'default'    => [
					'unit'   => 'px',
					'top'    => '10',
					'right'  => '10',
					'bottom' => '10',
					'left'   => '10',
				],
				'selectors'  => [
					'{{WRAPPER}} .omfag_btn .icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->end_controls_section();
	}

	/**
	 * Render list widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
		<a class="omfag_btn" href="<?php echo $settings['btn_url']['url'];?>">
			<span><?php echo $settings['title'];?></span>
			<div class="icon"><i class="fa-solid fa-arrow-right-long"></i></div>
		</a>
		<?php
	}

	/**
	 * Render list widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() {}
}