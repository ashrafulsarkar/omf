<?php
/**
 * Plugin Name: OMF Elementor Addon
 * Description: Custom Elementor addon For OMF Theme.
 * Plugin URI:  https://github.com/ashrafulsarkar
 * Version:     1.0.0
 * Author:      Ashraful Sarkar Naiem
 * Author URI:  https://github.com/ashrafulsarkar
 * Text Domain: omf
 * 
 * Elementor tested up to: 3.16.6
 * Elementor Pro tested up to: 3.16.2
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
define( 'OMF_ELEMENTOR_URL', plugin_dir_url(__FILE__) );
define( 'OMF_ELEMENTOR_CSS', OMF_ELEMENTOR_URL .'assets/css' );
define( 'OMF_ELEMENTOR_JS', OMF_ELEMENTOR_URL .'assets/js' );

function omf_elementor_addon() {

	// Load plugin file
	require_once( __DIR__ . '/includes/plugin.php' );

	// Run the plugin
	\OMF_Elementor_Addon\Plugin::instance();

}
add_action( 'plugins_loaded', 'omf_elementor_addon' );