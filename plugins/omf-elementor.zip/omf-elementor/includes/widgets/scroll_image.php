<?php
namespace OMF_Elementor_Addon;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class OMF_Scroll_Image extends \Elementor\Widget_Base {

	public function get_name() {
		return 'omf_scroll_image';
	}

	public function get_title() {
		return esc_html__( 'OMF Scroll Image', 'omf' );
	}

	public function get_icon() {
		return 'eicon-slider-album';
	}

	public function get_custom_help_url() {
		return 'https://developers.elementor.com/docs/widgets/';
	}

	public function get_categories() {
		return [ 'omf' ];
	}

	public function get_keywords() {
		return [ 'image', 'box', 'slider' ];
	}

	protected function register_controls() {



        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'omf' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'omf' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Residenz Neudorf' , 'omf' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'image',
			[
				'label'   => esc_html__( 'Image', 'omf' ),
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'list',
			[
				'label' => esc_html__( 'Repeater List', 'omf' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'title' => esc_html__( 'Residenz Neudorf', 'omf' ),
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

		$this->end_controls_section();







		$this->start_controls_section(
			'box_style',
			[
				'label' => esc_html__( 'Box Style', 'omf' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'box_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'omf' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'default'    => [
					'unit'   => 'px',
					'top'    => '10',
					'right'  => '10',
					'bottom' => '10',
					'left'   => '10',
				],
				'selectors'  => [
					'{{WRAPPER}} .omf_scroll_image, {{WRAPPER}} .omf_scroll_single_item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title Style', 'omf' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'omf' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#001C35',
				'selectors' => [
					'{{WRAPPER}} .omf_scroll_image_content h4' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .omf_scroll_image_content h4',
			]
		);

		$this->add_responsive_control(
			'title_position_top',
			[
				'label'      => esc_html__( 'Position Top', 'omf' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => ['px'],
                'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					]
				],
				'default'    => [
					'unit'   => 'px',
					'size' => '20',
				],
				'selectors'  => [
					'{{WRAPPER}} .omf_scroll_image_content' => 'top: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_responsive_control(
			'title_position_left',
			[
				'label'      => esc_html__( 'Position Left', 'omf' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => ['px'],
                'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					]
				],
				'default'    => [
					'unit'   => 'px',
					'size' => '24',
				],
				'selectors'  => [
					'{{WRAPPER}} .omf_scroll_image_content' => 'left: {{SIZE}}{{UNIT}}',
				],
			]
		);
		
		$this->end_controls_section();
	}

	/**
	 * Render list widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
        <div class="omf_scroll_box">
            <?php if ( $settings['list'] ) {;?>
                <?php foreach (  $settings['list'] as $item ) {;?>
                <div class="omf_scroll_single_item">
                    <div class="omf_scroll_image">
                        <img src="<?php echo $item['image']['url'];?>" alt="<?php echo $item['title'];?>">
                    </div>
                    <div class="omf_scroll_image_content">
                        <h4><?php echo $item['title'];?></h4>
                    </div>
                </div>
                <?php };?>
            <?php };?>
        </div>
		<?php
	}

	/**
	 * Render list widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() {}
}