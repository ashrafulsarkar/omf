<?php
namespace OMF_Elementor_Addon;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class OMF_Team_Box extends \Elementor\Widget_Base {

	public function get_name() {
		return 'omf_team_box';
	}

	public function get_title() {
		return esc_html__( 'OMF Team Box', 'omf' );
	}

	public function get_icon() {
		return 'eicon-image-hotspot';
	}

	public function get_custom_help_url() {
		return 'https://developers.elementor.com/docs/widgets/';
	}

	public function get_categories() {
		return [ 'omf' ];
	}

	public function get_keywords() {
		return [ 'image', 'box', 'team' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Image Box', 'omf' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'image',
			[
				'label'   => esc_html__( 'Image', 'omf' ),
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'omf' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Omer Fetai', 'omf' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'designation',
			[
				'label'       => esc_html__( 'Designation', 'omf' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'Inhaber und Projektleitung', 'omf' ),
				'label_block' => true,
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
			'content_box_style',
			[
				'label' => esc_html__( 'Content Box Style', 'omf' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
			'content_box_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'omf' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FAFCFF',
				'selectors' => [
					'{{WRAPPER}} .omf_team_content_box' => 'background: {{VALUE}};',
				],
			]
		);

        $this->add_responsive_control(
			'content_box_padding',
			[
				'label'      => esc_html__( 'Padding', 'omf' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'default'    => [
					'unit'   => 'px',
					'top'    => '12',
					'right'  => '12',
					'bottom' => '12',
					'left'   => '12',
				],
				'selectors'  => [
					'{{WRAPPER}} .omf_team_content_box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->add_responsive_control(
			'content_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'omf' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'default'    => [
					'unit'   => 'px',
					'top'    => '10',
					'right'  => '10',
					'bottom' => '10',
					'left'   => '10',
				],
				'selectors'  => [
					'{{WRAPPER}} .omf_team_content_box, {{WRAPPER}} .omf_team img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title Style', 'omf' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'omf' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#001C35',
				'selectors' => [
					'{{WRAPPER}} .omf_team_content h4' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .omf_team_content h4',
			]
		);

        $this->add_responsive_control(
			'title_align',
			[
				'label' => esc_html__( 'Alignment', 'omf' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'omf' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'omf' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'omf' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .omf_team_content h4' => 'text-align: {{VALUE}};',
				],
			]
		);

        $this->add_responsive_control(
			'title_bottom_space',
			[
				'label'      => esc_html__( 'Bottom Space', 'omf' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => ['px'],
                'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					]
				],
				'default'    => [
					'unit'   => 'px',
					'size' => '4',
				],
				'selectors'  => [
					'{{WRAPPER}} .omf_team_content h4' => 'padding-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->end_controls_section();

        $this->start_controls_section(
			'designation_style',
			[
				'label' => esc_html__( 'Designation Style', 'omf' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'designation_color',
			[
				'label'     => esc_html__( 'Color', 'omf' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#001C35',
				'selectors' => [
					'{{WRAPPER}} .omf_team_content h5' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'designation_typography',
				'selector' => '{{WRAPPER}} .omf_team_content h5',
			]
		);

        $this->add_responsive_control(
			'designation_align',
			[
				'label' => esc_html__( 'Alignment', 'omf' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'omf' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'omf' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'omf' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .omf_team_content h5' => 'text-align: {{VALUE}};',
				],
			]
		);
		
		$this->end_controls_section();
	}

	/**
	 * Render list widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
        <div class="omf_team_box">
            <div class="omf_team">
                <img src="<?php echo $settings['image']['url'];?>" alt="<?php echo $settings['title'];?>">
            </div>
            <div class="omf_team_content">
                <div class="omf_team_content_box">
                    <h4><?php echo $settings['title'];?></h4>
                    <h5><?php echo $settings['designation'];?></h5>
                </div>
            </div>
        </div>
		<?php
	}

	/**
	 * Render list widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() {}
}